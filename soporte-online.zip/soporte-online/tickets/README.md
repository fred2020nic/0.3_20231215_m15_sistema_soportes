# Sistema de Tickets y Servicios en PHP y MySQL
<img src="Sistema%20de%20Tickets%20y%20Servicios%20en%20PHP%20y%20MySQL.png">
Este sistema se puede utilizar para equipos de soporte técnico y solicitar servicios específicos, el proceso de su implementación se explica en el post a continuación:
https://www.configuroweb.com/sistema-de-tickets-y-servicios-en-php-y-mysql/

# Nota importante
La aplicación tiene un coste de 15 USD, requieres de la base de datos para ponerla a punto, mi cuenta de PayPal es msevillab@gmail.com y si tienes cualquier duda me puedes contactar a mi Whatsapp en el siguiente enlace:

https://configuroweb.com/WhatsappMessenger
