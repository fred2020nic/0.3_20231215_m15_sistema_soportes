<?php

$conn = new mysqli('localhost', 'root', 'root', 'soporte-tecnico') or die("Could not connect to mysql" . mysqli_error($con));

mysqli_query($conn, "SET SESSION sql_mode = ''");
